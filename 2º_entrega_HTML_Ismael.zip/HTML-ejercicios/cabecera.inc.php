
<header>
    <h1>Mi Sitio Web</h1>
    <nav>
        <ul>
            <li><a href="principal.php">Inicio</a></li>
            <li><a href="rrss.php">rrss</a></li>
            <li><a href="tecnologias.php">tecnologias</a></li>
        </ul>
    </nav>
</header>
